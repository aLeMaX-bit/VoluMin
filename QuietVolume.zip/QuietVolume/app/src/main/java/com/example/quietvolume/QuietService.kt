package com.example.quietvolume

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.IBinder
import android.widget.Toast

class QuietService : Service() {

    private var enhancer: LoudnessEnhancer? = null

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "quiet"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val db = intent?.getIntExtra("db", 10) ?: 10

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Quiet Volume", NotificationManager.IMPORTANCE_LOW)
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Quiet Volume aktif")
            .setContentText("Redaman tambahan: -$db dB")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, notif)
        }

        try {
            if (enhancer == null) {
                // Session 0 = efek global untuk seluruh output audio.
                enhancer = LoudnessEnhancer(0).also { it.enabled = true }
            }
            enhancer?.setTargetGain(-db * 100) // satuan millibel, negatif = meredam
            running = true
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Efek audio global tidak didukung di HP ini: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        enhancer?.release()
        enhancer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
