package com.example.quietvolume

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private var db = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        db = prefs.getInt("db", 10)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        val label = TextView(this).apply { textSize = 20f }
        val seek = SeekBar(this).apply { max = 40; progress = db }
        val start = Button(this).apply { text = "Aktifkan / Terapkan" }
        val stop = Button(this).apply { text = "Matikan" }
        val note = TextView(this).apply {
            text = "Turunkan volume HP ke level terendah dulu, lalu geser slider " +
                "untuk meredam suara lebih jauh (0-40 dB)."
            setPadding(0, pad, 0, 0)
        }

        fun refresh() { label.text = "Redaman tambahan: -$db dB" }

        fun applyGain() {
            prefs.edit().putInt("db", db).apply()
            startForegroundService(
                Intent(this, QuietService::class.java).putExtra("db", db)
            )
        }

        refresh()

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                db = p
                refresh()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                prefs.edit().putInt("db", db).apply()
                if (QuietService.running) applyGain()
            }
        })

        start.setOnClickListener { applyGain() }
        stop.setOnClickListener { stopService(Intent(this, QuietService::class.java)) }

        root.addView(label)
        root.addView(seek)
        root.addView(start)
        root.addView(stop)
        root.addView(note)
        setContentView(root)
    }
}
