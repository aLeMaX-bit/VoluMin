package com.example.quietvolume

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.widget.Button

object Ui {
    // Warna diambil dari logo VoluMin
    val NAVY = Color.parseColor("#0A1A4A")
    val BLUE = Color.parseColor("#1F52C0")
    val CYAN = Color.parseColor("#5CF0FF")
    val PANEL = Color.parseColor("#D9071436")
    val MUTED = Color.parseColor("#A9C4F5")
    val WHITE = Color.WHITE

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun background(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(NAVY, BLUE)
    )

    fun styleBars(a: Activity) {
        a.window.statusBarColor = NAVY
        a.window.navigationBarColor = BLUE
    }

    fun button(ctx: Context, label: String, filled: Boolean): Button {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(ctx, 16).toFloat()
            if (filled) {
                setColor(CYAN)
            } else {
                setColor(Color.TRANSPARENT)
                setStroke(dp(ctx, 2), CYAN)
            }
        }
        val ripple = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), bg, null)
        return Button(ctx).apply {
            text = label
            isAllCaps = true
            textSize = 16f
            setTextColor(if (filled) NAVY else CYAN)
            background = ripple
            stateListAnimator = null
            minimumHeight = dp(ctx, 60)
        }
    }
}
