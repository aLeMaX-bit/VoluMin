# Quiet Volume

Meredam volume HP Android lebih pelan dari level minimum bawaan, memakai `LoudnessEnhancer` (gain negatif) pada audio session global.

## Build lewat GitHub
1. Push repo ini ke GitHub (branch `main`).
2. Buka tab **Actions** > workflow **Build APK** > tunggu selesai.
3. Unduh artifact **QuietVolume-debug-apk**, ekstrak, lalu install `app-debug.apk`.
