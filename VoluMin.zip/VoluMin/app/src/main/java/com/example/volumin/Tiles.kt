package com.example.volumin

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

@Suppress("DEPRECATION")
private fun TileService.openApp() {
    val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (Build.VERSION.SDK_INT >= 34) {
        startActivityAndCollapse(
            PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        )
    } else {
        startActivityAndCollapse(intent)
    }
}

private fun TileService.savedDb(): Int =
    getSharedPreferences("prefs", MODE_PRIVATE).getInt("db", 10)

/** Tile utama: ketuk untuk aktif / jeda / lanjutkan. Menampilkan persentase. */
class MainTile : TileService() {

    override fun onStartListening() {
        refresh()
    }

    override fun onClick() {
        try {
            if (VoluMinService.running) {
                startService(
                    Intent(this, VoluMinService::class.java).setAction(VoluMinService.ACTION_TOGGLE)
                )
            } else {
                startForegroundService(
                    Intent(this, VoluMinService::class.java)
                        .setAction(VoluMinService.ACTION_APPLY)
                        .putExtra("db", savedDb())
                )
            }
        } catch (e: Exception) {
            openApp() // sistem tidak mengizinkan start dari sini, buka aplikasinya saja
        }
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 500)
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = VoluMinService.running
        val paused = on && VoluMinService.paused
        t.label = "VoluMin"
        t.state = if (on && !paused) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) {
            t.subtitle = when {
                !on -> getString(R.string.s_off)
                paused -> getString(R.string.s_paused)
                else -> "${Level.percent(savedDb())}%"
            }
        }
        t.updateTile()
    }
}

/** Tile − / +: ubah redaman langkah demi langkah dari panel Pengaturan Cepat. */
abstract class StepTile(private val action: String, private val sign: Int) : TileService() {

    override fun onStartListening() {
        refresh()
    }

    override fun onClick() {
        if (VoluMinService.running) {
            try {
                startService(Intent(this, VoluMinService::class.java).setAction(action))
            } catch (e: Exception) {
                // abaikan
            }
        } else {
            val db = (savedDb() + sign * Level.STEP).coerceIn(0, Level.MAX_DB)
            getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("db", db).apply()
        }
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 400)
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.label = if (sign > 0) "VoluMin \u2212" else "VoluMin +"
        t.state = if (VoluMinService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = "${Level.percent(savedDb())}%"
        t.updateTile()
    }
}

class QuieterTile : StepTile(VoluMinService.ACTION_QUIETER, 1)

class LouderTile : StepTile(VoluMinService.ACTION_LOUDER, -1)
