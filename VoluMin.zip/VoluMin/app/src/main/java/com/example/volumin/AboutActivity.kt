package com.example.volumin

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class AboutActivity : Activity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.styleBars(this)

        val pad = Ui.dp(this, 24)
        val match = LinearLayout.LayoutParams.MATCH_PARENT
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.background()
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }

        val logo = ImageView(this).apply { setImageResource(R.drawable.logo) }
        content.addView(logo, LinearLayout.LayoutParams(Ui.dp(this, 112), Ui.dp(this, 112)))

        val title = TextView(this).apply {
            text = "VoluMin"
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(Ui.CYAN)
            setShadowLayer(24f, 0f, 0f, Ui.CYAN)
            setPadding(0, Ui.dp(this@AboutActivity, 16), 0, 0)
        }
        content.addView(title, LinearLayout.LayoutParams(match, wrap))

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            null
        }
        val ver = TextView(this).apply {
            text = getString(R.string.about_version, version ?: "1.0")
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Ui.MUTED)
        }
        content.addView(ver, LinearLayout.LayoutParams(match, wrap))

        val desc = TextView(this).apply {
            text = getString(R.string.about_desc)
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Ui.WHITE)
            setPadding(0, Ui.dp(this@AboutActivity, 20), 0, Ui.dp(this@AboutActivity, 28))
        }
        content.addView(desc, LinearLayout.LayoutParams(match, wrap))

        addSection(content, getString(R.string.lbl_by), AboutInfo.DEVELOPER)
        addSection(content, getString(R.string.lbl_bio), AboutInfo.BIO)
        addSection(content, "Email", AboutInfo.EMAIL)
        addSection(content, "Instagram", AboutInfo.INSTAGRAM)
        addSection(content, "Website", AboutInfo.WEBSITE)

        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(match, 0, 1f))

        // Tombol di bawah supaya mudah dijangkau satu tangan
        val back = Ui.button(this, getString(R.string.btn_back), true)
        back.setOnClickListener { finish() }
        root.addView(back, LinearLayout.LayoutParams(match, wrap).apply {
            setMargins(pad, Ui.dp(this@AboutActivity, 12), pad, pad)
        })

        // Edge-to-edge: beri ruang untuk status bar / navigation bar
        root.setOnApplyWindowInsetsListener { _, ins ->
            val b = Ui.insets(ins)
            root.setPadding(b[0], b[1], b[2], b[3])
            ins
        }
        setContentView(root)
    }

    private fun addSection(parent: LinearLayout, label: String, value: String) {
        val bottom = Ui.dp(this, 18)
        val top = Ui.dp(this, 2)
        val l = TextView(this).apply {
            text = label.uppercase()
            textSize = 12f
            gravity = Gravity.CENTER
            letterSpacing = 0.1f
            setTextColor(Ui.CYAN)
        }
        val v = TextView(this).apply {
            text = value
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Ui.WHITE)
            setPadding(0, top, 0, bottom)
        }
        val lp = LinearLayout.LayoutParams.MATCH_PARENT
        val wp = LinearLayout.LayoutParams.WRAP_CONTENT
        parent.addView(l, LinearLayout.LayoutParams(lp, wp))
        parent.addView(v, LinearLayout.LayoutParams(lp, wp))
    }
}
