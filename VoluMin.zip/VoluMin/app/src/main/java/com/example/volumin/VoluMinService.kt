package com.example.volumin

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.IBinder
import android.widget.Toast

class VoluMinService : Service() {

    private var enhancer: LoudnessEnhancer? = null
    private var db = 10

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "voluMin"
        private const val STEP = 5          // langkah tombol notifikasi (dB)
        private const val MAX_DB = 40
        const val ACTION_QUIETER = "com.example.volumin.QUIETER"
        const val ACTION_LOUDER = "com.example.volumin.LOUDER"
        const val ACTION_STOP = "com.example.volumin.STOP"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        db = intent?.getIntExtra("db", prefs.getInt("db", 10)) ?: prefs.getInt("db", 10)

        when (intent?.action) {
            ACTION_QUIETER -> db = minOf(MAX_DB, prefs.getInt("db", db) + STEP)
            ACTION_LOUDER -> db = maxOf(0, prefs.getInt("db", db) - STEP)
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        prefs.edit().putInt("db", db).apply()

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "VoluMin", NotificationManager.IMPORTANCE_LOW)
        )
        val notif = buildNotification(db)

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, notif)
        }

        try {
            if (enhancer == null) {
                // Session 0 = efek global untuk seluruh output audio.
                enhancer = LoudnessEnhancer(0).also { it.enabled = true }
            }
            enhancer?.setTargetGain(-db * 100) // satuan millibel, negatif = meredam
            running = true
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Efek audio global tidak didukung di HP ini: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
        }
        return START_STICKY
    }

    private fun actionIntent(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, VoluMinService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun action(title: String, iconRes: Int, pi: PendingIntent): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(this, iconRes), title, pi).build()

    private fun buildNotification(db: Int): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("VoluMin aktif")
            .setContentText("Redaman tambahan: -$db dB")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .addAction(action("Lebih pelan", android.R.drawable.ic_media_rew, actionIntent(ACTION_QUIETER, 1)))
            .addAction(action("Lebih keras", android.R.drawable.ic_media_ff, actionIntent(ACTION_LOUDER, 2)))
            .addAction(action("Berhenti", android.R.drawable.ic_menu_close_clear_cancel, actionIntent(ACTION_STOP, 3)))
            .build()
    }

    override fun onDestroy() {
        running = false
        enhancer?.release()
        enhancer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
