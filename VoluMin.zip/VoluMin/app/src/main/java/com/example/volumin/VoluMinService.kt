package com.example.volumin

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.IBinder
import android.widget.RemoteViews
import android.widget.Toast

class VoluMinService : Service() {

    private var enhancer: LoudnessEnhancer? = null
    private var db = 10

    companion object {
        @Volatile var running = false
        private const val CHANNEL_PINNED = "volumin_pinned"
        private const val CHANNEL_NORMAL = "volumin_normal"
        private const val STEP = 5          // langkah tombol - dan + (dB)
        private const val MAX_DB = 40
        const val ACTION_QUIETER = "com.example.volumin.QUIETER"
        const val ACTION_LOUDER = "com.example.volumin.LOUDER"
        const val ACTION_PIN = "com.example.volumin.PIN"
        const val ACTION_STOP = "com.example.volumin.STOP"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        db = intent?.getIntExtra("db", prefs.getInt("db", 10)) ?: prefs.getInt("db", 10)

        when (intent?.action) {
            ACTION_QUIETER -> db = minOf(MAX_DB, prefs.getInt("db", db) + STEP)
            ACTION_LOUDER -> db = maxOf(0, prefs.getInt("db", db) - STEP)
            ACTION_PIN -> prefs.edit()
                .putBoolean("pinned", !prefs.getBoolean("pinned", true)).apply()
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        prefs.edit().putInt("db", db).apply()
        val pinned = prefs.getBoolean("pinned", true)

        ensureChannels()
        val notif = buildNotification(db, pinned)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, notif)
        }

        try {
            if (enhancer == null) {
                // Session 0 = efek global untuk seluruh output audio.
                enhancer = LoudnessEnhancer(0).also { it.enabled = true }
            }
            enhancer?.setTargetGain(-db * 100) // satuan millibel, negatif = meredam
            running = true
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Efek audio global tidak didukung di HP ini: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
        }
        return START_STICKY
    }

    private fun ensureChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        // Disematkan: tingkat "default" tapi tanpa suara/getar, supaya naik ke bagian atas laci.
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_PINNED, "VoluMin (disematkan di atas)",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
        )
        // Biasa: tingkat rendah, bisa tertimbun notifikasi lain.
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_NORMAL, "VoluMin (biasa)",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
        )
    }

    private fun actionIntent(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, VoluMinService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buildNotification(db: Int, pinned: Boolean): Notification {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val fg = if (night) Color.WHITE else Color.parseColor("#202124")
        val dim = Color.argb(110, Color.red(fg), Color.green(fg), Color.blue(fg))
        val pinColor = if (pinned) (if (night) Ui.CYAN else Ui.BLUE) else dim
        val powerRed = Color.parseColor("#FF4D4D")

        val rv = RemoteViews(packageName, R.layout.notif_controls)
        rv.setTextViewText(R.id.notif_text, "VoluMin  •  " + if (db == 0) "0 dB" else "-$db dB")
        rv.setTextColor(R.id.notif_text, fg)
        rv.setInt(R.id.btn_minus, "setColorFilter", fg)
        rv.setInt(R.id.btn_plus, "setColorFilter", fg)
        rv.setInt(R.id.btn_pin, "setColorFilter", pinColor)
        rv.setInt(R.id.btn_power, "setColorFilter", powerRed)
        rv.setOnClickPendingIntent(R.id.btn_minus, actionIntent(ACTION_QUIETER, 1))
        rv.setOnClickPendingIntent(R.id.btn_plus, actionIntent(ACTION_LOUDER, 2))
        rv.setOnClickPendingIntent(R.id.btn_pin, actionIntent(ACTION_PIN, 3))
        rv.setOnClickPendingIntent(R.id.btn_power, actionIntent(ACTION_STOP, 4))

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        val b = Notification.Builder(this, if (pinned) CHANNEL_PINNED else CHANNEL_NORMAL)
            .setSmallIcon(R.drawable.ic_stat_volume)
            .setContentTitle("VoluMin aktif")
            .setContentText("Redaman tambahan: -$db dB")
            .setContentIntent(open)
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(rv)
            .setCustomBigContentView(rv)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    override fun onDestroy() {
        running = false
        enhancer?.release()
        enhancer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
