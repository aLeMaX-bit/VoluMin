package com.example.volumin

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.IBinder
import android.widget.RemoteViews
import android.widget.Toast

class VoluMinService : Service() {

    private var enhancer: LoudnessEnhancer? = null
    private var db = 10

    companion object {
        @Volatile var running = false
        @Volatile var paused = false
        private const val CHANNEL = "volumin_pinned"
        const val ACTION_APPLY = "com.example.volumin.APPLY"     // dari tombol Aktifkan (otomatis melanjutkan)
        const val ACTION_SET = "com.example.volumin.SET"         // dari slider
        const val ACTION_QUIETER = "com.example.volumin.QUIETER"
        const val ACTION_LOUDER = "com.example.volumin.LOUDER"
        const val ACTION_TOGGLE = "com.example.volumin.TOGGLE"   // jeda / lanjutkan
        const val ACTION_STOP = "com.example.volumin.STOP"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        db = prefs.getInt("db", 10)
        paused = prefs.getBoolean("paused", false)

        when (intent?.action) {
            ACTION_APPLY -> {
                db = intent?.getIntExtra("db", db) ?: db
                paused = false
            }
            ACTION_SET -> db = intent?.getIntExtra("db", db) ?: db
            ACTION_QUIETER -> db = minOf(Level.MAX_DB, db + Level.STEP)
            ACTION_LOUDER -> db = maxOf(0, db - Level.STEP)
            ACTION_TOGGLE -> paused = !paused
            ACTION_STOP -> {
                prefs.edit().putBoolean("paused", false).apply()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        prefs.edit().putInt("db", db).putBoolean("paused", paused).apply()

        ensureChannel()
        val notif = buildNotification(db, paused)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, notif)
        }

        try {
            // Session 0 = efek global untuk seluruh output audio.
            val e = enhancer ?: LoudnessEnhancer(0).also { enhancer = it }
            e.setTargetGain(-db * 100) // satuan millibel, negatif = meredam
            e.enabled = !paused         // jeda = efek dimatikan sementara
            running = true
        } catch (ex: Exception) {
            Toast.makeText(
                this,
                getString(R.string.toast_unsupported, ex.message ?: ""),
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
        }
        return START_STICKY
    }

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        // Tingkat "default" tanpa suara/getar: masuk bagian atas laci, di atas yang "Senyap".
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "VoluMin", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
        )
    }

    private fun actionIntent(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, VoluMinService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buildNotification(db: Int, paused: Boolean): Notification {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val fg = if (night) Color.WHITE else Color.parseColor("#202124")
        val dim = Color.argb(110, Color.red(fg), Color.green(fg), Color.blue(fg))
        val accent = if (night) Ui.CYAN else Ui.BLUE
        val powerRed = Color.parseColor("#FF4D4D")

        val rv = RemoteViews(packageName, R.layout.notif_controls)
        rv.setTextViewText(R.id.notif_text, "${Level.percent(db)}%")
        rv.setTextColor(R.id.notif_text, if (paused) dim else fg)
        rv.setInt(R.id.btn_minus, "setColorFilter", fg)
        rv.setInt(R.id.btn_plus, "setColorFilter", fg)
        rv.setImageViewResource(R.id.btn_pause, if (paused) R.drawable.ic_play else R.drawable.ic_pause)
        rv.setInt(R.id.btn_pause, "setColorFilter", accent)
        rv.setCharSequence(
            R.id.btn_pause, "setContentDescription",
            getString(if (paused) R.string.btn_resume else R.string.btn_pause)
        )
        rv.setInt(R.id.btn_power, "setColorFilter", powerRed)
        rv.setOnClickPendingIntent(R.id.btn_minus, actionIntent(ACTION_QUIETER, 1))
        rv.setOnClickPendingIntent(R.id.btn_plus, actionIntent(ACTION_LOUDER, 2))
        rv.setOnClickPendingIntent(R.id.btn_pause, actionIntent(ACTION_TOGGLE, 3))
        rv.setOnClickPendingIntent(R.id.btn_power, actionIntent(ACTION_STOP, 4))

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_volume)
            .setContentTitle("VoluMin")
            .setContentText("${Level.percent(db)}%" + if (paused) "  \u275A\u275A" else "")
            .setContentIntent(open)
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(rv)
            .setCustomBigContentView(rv)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setShowWhen(false)
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    override fun onDestroy() {
        running = false
        enhancer?.release()
        enhancer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
