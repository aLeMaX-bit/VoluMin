package com.example.volumin

// Data pembuat. Ganti isi di bawah ini nanti.
object AboutInfo {
    const val DEVELOPER = "[Nama Pembuat]"
    const val BIO = "[Penjelasan singkat tentang pembuat]"
    const val EMAIL = "[email@contoh.com]"
    const val INSTAGRAM = "[@username]"
    const val WEBSITE = "[https://situs-kamu.com]"
}
