package com.example.volumin

import kotlin.math.pow
import kotlin.math.roundToInt

object Level {
    const val MAX_DB = 40
    const val STEP = 5      // langkah tombol - dan + (dB)

    /** Persentase kekerasan terhadap volume HP. 0 dB = 100%, 6 dB = 50%, 20 dB = 10%, 40 dB = 1%. */
    fun percent(db: Int): Int =
        (100.0 * 10.0.pow(-db / 20.0)).roundToInt().coerceAtLeast(1)

    fun dbText(db: Int): String = if (db == 0) "0 dB" else "-$db dB"
}
