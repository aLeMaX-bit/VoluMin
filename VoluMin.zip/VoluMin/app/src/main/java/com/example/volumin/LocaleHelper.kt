package com.example.volumin

import android.app.Activity
import android.app.LocaleManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import java.util.Locale

object LocaleHelper {

    /** Nama bahasa (ditulis dalam bahasanya sendiri) dan kode bahasanya. */
    val languages: List<Pair<String, String>> = listOf(
        "English" to "en",
        "Bahasa Indonesia" to "id",
        "中文" to "zh-CN",
        "Español" to "es",
        "हिन्दी" to "hi",
        "العربية" to "ar",
        "বাংলা" to "bn",
        "Português" to "pt",
        "Русский" to "ru",
        "日本語" to "ja",
        "اردو" to "ur",
        "Deutsch" to "de",
        "Français" to "fr",
        "Türkçe" to "tr",
        "한국어" to "ko",
        "Tiếng Việt" to "vi",
        "Italiano" to "it",
        "ไทย" to "th",
        "فارسی" to "fa",
        "Polski" to "pl",
        "தமிழ்" to "ta",
        "मराठी" to "mr",
        "తెలుగు" to "te",
        "Kiswahili" to "sw",
        "Nederlands" to "nl",
        "Bahasa Melayu" to "ms",
        "Українська" to "uk",
        "Filipino" to "fil",
        "Română" to "ro",
        "ਪੰਜਾਬੀ" to "pa"
    )

    /** Kode bahasa pilihan saat ini. Kosong berarti ikut bahasa sistem. */
    fun current(ctx: Context): String =
        if (Build.VERSION.SDK_INT >= 33) {
            val l = ctx.getSystemService(LocaleManager::class.java).applicationLocales
            if (l.isEmpty()) "" else l.get(0).toLanguageTag()
        } else {
            ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("lang", "") ?: ""
        }

    /** Terapkan bahasa. Layar dibuat ulang otomatis. */
    fun apply(activity: Activity, tag: String) {
        if (Build.VERSION.SDK_INT >= 33) {
            // Sistem menyimpan pilihan ini dan membuat ulang layar dengan sendirinya.
            activity.getSystemService(LocaleManager::class.java).applicationLocales =
                if (tag.isEmpty()) LocaleList.getEmptyLocaleList() else LocaleList.forLanguageTags(tag)
        } else {
            activity.getSharedPreferences("prefs", Context.MODE_PRIVATE)
                .edit().putString("lang", tag).apply()
            activity.recreate()
        }
    }

    /** Android 12 ke bawah: pasang bahasa pilihan ke konteks. Android 13+ sudah ditangani sistem. */
    fun wrap(base: Context): Context {
        if (Build.VERSION.SDK_INT >= 33) return base
        val tag = base.getSharedPreferences("prefs", Context.MODE_PRIVATE)
            .getString("lang", "") ?: ""
        if (tag.isEmpty()) return base
        val locale = Locale.forLanguageTag(tag)
        Locale.setDefault(locale)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        return base.createConfigurationContext(cfg)
    }
}
