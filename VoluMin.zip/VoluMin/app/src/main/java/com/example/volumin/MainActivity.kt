package com.example.volumin

import android.Manifest
import android.app.Activity
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private var db = 10
    private lateinit var readout: TextView
    private lateinit var caption: TextView
    private lateinit var status: TextView
    private lateinit var seek: SeekBar
    private lateinit var pauseBtn: Button
    private val handler = Handler(Looper.getMainLooper())

    private fun serviceIntent(action: String): Intent =
        Intent(this, VoluMinService::class.java).setAction(action).putExtra("db", db)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.styleBars(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        db = prefs.getInt("db", 10)

        val pad = Ui.dp(this, 24)
        val gap = Ui.dp(this, 12)
        val match = LinearLayout.LayoutParams.MATCH_PARENT
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.background()
        }

        // ---- Bagian atas: hanya info (tidak perlu dijangkau) ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.logo) }
        header.addView(logo, LinearLayout.LayoutParams(Ui.dp(this, 96), Ui.dp(this, 96)))

        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            letterSpacing = 0.15f
            setPadding(0, Ui.dp(this@MainActivity, 16), 0, 0)
        }
        header.addView(status, LinearLayout.LayoutParams(match, wrap))

        readout = TextView(this).apply {
            textSize = 72f
            gravity = Gravity.CENTER
            setTextColor(Ui.CYAN)
            setShadowLayer(32f, 0f, 0f, Ui.CYAN) // efek neon
        }
        header.addView(readout, LinearLayout.LayoutParams(match, wrap))

        caption = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Ui.MUTED)
        }
        header.addView(caption, LinearLayout.LayoutParams(match, wrap))

        root.addView(header, LinearLayout.LayoutParams(match, 0, 1f))

        // ---- Bagian bawah: semua kontrol, mudah dijangkau satu tangan ----
        val r = Ui.dp(this, 28).toFloat()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(Ui.PANEL)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }

        val hint = TextView(this).apply {
            text = getString(R.string.hint)
            textSize = 13f
            setTextColor(Ui.MUTED)
        }
        panel.addView(hint, LinearLayout.LayoutParams(match, wrap))

        seek = SeekBar(this).apply {
            max = Level.MAX_DB
            progress = Level.MAX_DB - db // kiri = pelan, kanan = keras
            progressTintList = ColorStateList.valueOf(Ui.CYAN)
            thumbTintList = ColorStateList.valueOf(Ui.CYAN)
            progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
            setPadding(
                Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 22),
                Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 22)
            )
        }
        panel.addView(seek, LinearLayout.LayoutParams(match, wrap))

        val apply = Ui.button(this, getString(R.string.btn_apply), true)
        pauseBtn = Ui.button(this, getString(R.string.btn_pause), false).apply { textSize = 14f }
        val stop = Ui.button(this, getString(R.string.btn_stop), false).apply { textSize = 14f }

        panel.addView(apply, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = gap })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pauseBtn, LinearLayout.LayoutParams(0, wrap, 1f).apply { rightMargin = gap / 2 })
        row.addView(stop, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = gap / 2 })
        panel.addView(row, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = gap })

        if (Build.VERSION.SDK_INT >= 33) {
            val tileLink = makeLink(getString(R.string.tile_link))
            tileLink.setOnClickListener { addTiles(0) }
            panel.addView(tileLink, LinearLayout.LayoutParams(match, wrap))
        }

        val about = makeLink(getString(R.string.about_link))
        about.setOnClickListener { startActivity(Intent(this, AboutActivity::class.java)) }
        panel.addView(about, LinearLayout.LayoutParams(match, wrap))

        root.addView(panel, LinearLayout.LayoutParams(match, wrap))

        // Edge-to-edge: beri ruang untuk status bar / navigation bar
        root.setOnApplyWindowInsetsListener { _, ins ->
            val b = Ui.insets(ins)
            root.setPadding(b[0], b[1], b[2], 0)
            panel.setPadding(pad, pad, pad, pad + b[3])
            ins
        }
        setContentView(root)

        refresh()
        updateStatus()

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                db = Level.MAX_DB - p
                refresh()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                prefs.edit().putInt("db", db).apply()
                if (VoluMinService.running) startService(serviceIntent(VoluMinService.ACTION_SET))
            }
        })

        apply.setOnClickListener {
            prefs.edit().putInt("db", db).apply()
            startForegroundService(serviceIntent(VoluMinService.ACTION_APPLY))
            handler.postDelayed({ updateStatus() }, 500)
        }
        pauseBtn.setOnClickListener {
            if (VoluMinService.running) {
                startService(serviceIntent(VoluMinService.ACTION_TOGGLE))
                handler.postDelayed({ updateStatus() }, 300)
            }
        }
        stop.setOnClickListener {
            stopService(Intent(this, VoluMinService::class.java))
            handler.postDelayed({ updateStatus() }, 300)
        }
    }

    private fun makeLink(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(Ui.MUTED)
        setPadding(0, Ui.dp(this@MainActivity, 12), 0, Ui.dp(this@MainActivity, 6))
    }

    private fun addTiles(i: Int) {
        if (Build.VERSION.SDK_INT < 33) return
        val items = listOf(
            Triple(MainTile::class.java, "VoluMin", R.drawable.ic_stat_volume),
            Triple(QuieterTile::class.java, "VoluMin \u2212", R.drawable.ic_minus),
            Triple(LouderTile::class.java, "VoluMin +", R.drawable.ic_plus)
        )
        if (i >= items.size) return
        val (cls, label, icon) = items[i]
        getSystemService(StatusBarManager::class.java).requestAddTileService(
            ComponentName(this, cls), label, Icon.createWithResource(this, icon), mainExecutor
        ) { _ -> addTiles(i + 1) }
    }

    private fun refresh() {
        readout.text = "${Level.percent(db)}%"
        caption.text = getString(R.string.caption_fmt, Level.dbText(db))
    }

    override fun onResume() {
        super.onResume()
        // sinkronkan slider kalau redaman diubah lewat notifikasi atau tile
        val saved = getSharedPreferences("prefs", MODE_PRIVATE).getInt("db", db)
        if (::seek.isInitialized && saved != db) seek.progress = Level.MAX_DB - saved
        updateStatus()
    }

    private fun updateStatus() {
        val on = VoluMinService.running
        val paused = on && VoluMinService.paused
        status.text = when {
            !on -> "\u25CB " + getString(R.string.s_off)
            paused -> "\u275A\u275A " + getString(R.string.s_paused)
            else -> "\u25CF " + getString(R.string.s_active)
        }
        status.setTextColor(if (on && !paused) Ui.CYAN else Ui.MUTED)
        pauseBtn.text = getString(if (paused) R.string.btn_resume else R.string.btn_pause)
        pauseBtn.isEnabled = on
        pauseBtn.alpha = if (on) 1f else 0.4f
    }
}
