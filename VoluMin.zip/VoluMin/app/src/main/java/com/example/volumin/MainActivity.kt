package com.example.volumin

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private var db = 10
    private lateinit var readout: TextView
    private lateinit var status: TextView
    private lateinit var seek: SeekBar
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.styleBars(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        db = prefs.getInt("db", 10)

        val pad = Ui.dp(this, 24)
        val match = LinearLayout.LayoutParams.MATCH_PARENT
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.background()
        }

        // ---- Bagian atas: hanya info (tidak perlu dijangkau) ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.logo) }
        header.addView(logo, LinearLayout.LayoutParams(Ui.dp(this, 96), Ui.dp(this, 96)))

        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            letterSpacing = 0.15f
            setPadding(0, Ui.dp(this@MainActivity, 16), 0, 0)
        }
        header.addView(status, LinearLayout.LayoutParams(match, wrap))

        readout = TextView(this).apply {
            textSize = 72f
            gravity = Gravity.CENTER
            setTextColor(Ui.CYAN)
            setShadowLayer(32f, 0f, 0f, Ui.CYAN) // efek neon
        }
        header.addView(readout, LinearLayout.LayoutParams(match, wrap))

        val caption = TextView(this).apply {
            text = "dB redaman tambahan"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Ui.MUTED)
        }
        header.addView(caption, LinearLayout.LayoutParams(match, wrap))

        root.addView(header, LinearLayout.LayoutParams(match, 0, 1f))

        // ---- Bagian bawah: semua kontrol, mudah dijangkau satu tangan ----
        val r = Ui.dp(this, 28).toFloat()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(Ui.PANEL)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }

        val hint = TextView(this).apply {
            text = "Turunkan volume HP ke level terendah dulu, lalu geser slider (0-40 dB)."
            textSize = 13f
            setTextColor(Ui.MUTED)
        }
        panel.addView(hint, LinearLayout.LayoutParams(match, wrap))

        seek = SeekBar(this).apply {
            max = 40
            progress = db
            progressTintList = ColorStateList.valueOf(Ui.CYAN)
            thumbTintList = ColorStateList.valueOf(Ui.CYAN)
            progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
            // area sentuh lebih tinggi supaya mudah digeser dengan jempol
            setPadding(Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 22),
                Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 22))
        }
        panel.addView(seek, LinearLayout.LayoutParams(match, wrap))

        val start = Ui.button(this, "Aktifkan / Terapkan", true)
        val stop = Ui.button(this, "Matikan", false)
        val gap = Ui.dp(this, 12)
        panel.addView(start, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = gap })
        panel.addView(stop, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = gap })

        val about = TextView(this).apply {
            text = "Tentang VoluMin"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Ui.MUTED)
            setPadding(0, Ui.dp(this@MainActivity, 14), 0, Ui.dp(this@MainActivity, 6))
        }
        panel.addView(about, LinearLayout.LayoutParams(match, wrap))

        root.addView(panel, LinearLayout.LayoutParams(match, wrap))

        // Edge-to-edge: beri ruang untuk status bar / navigation bar
        root.setOnApplyWindowInsetsListener { _, ins ->
            val b = Ui.insets(ins)
            root.setPadding(b[0], b[1], b[2], 0)
            panel.setPadding(pad, pad, pad, pad + b[3])
            ins
        }
        setContentView(root)

        fun refresh() {
            readout.text = if (db == 0) "0" else "-$db"
        }

        fun applyGain() {
            prefs.edit().putInt("db", db).apply()
            startForegroundService(
                Intent(this, VoluMinService::class.java).putExtra("db", db)
            )
            handler.postDelayed({ updateStatus() }, 500)
        }

        refresh()
        updateStatus()

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                db = p
                refresh()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                prefs.edit().putInt("db", db).apply()
                if (VoluMinService.running) applyGain()
            }
        })

        start.setOnClickListener { applyGain() }
        stop.setOnClickListener {
            stopService(Intent(this, VoluMinService::class.java))
            handler.postDelayed({ updateStatus() }, 300)
        }
        about.setOnClickListener { startActivity(Intent(this, AboutActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        // sinkronkan slider kalau redaman diubah lewat tombol notifikasi
        val saved = getSharedPreferences("prefs", MODE_PRIVATE).getInt("db", db)
        if (::seek.isInitialized && saved != db) seek.progress = saved
        updateStatus()
    }

    private fun updateStatus() {
        val on = VoluMinService.running
        status.text = if (on) "● AKTIF" else "○ MATI"
        status.setTextColor(if (on) Ui.CYAN else Ui.MUTED)
    }
}
