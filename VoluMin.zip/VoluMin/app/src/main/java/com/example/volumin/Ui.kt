package com.example.volumin

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.widget.Button

object Ui {
    // Warna diambil dari logo VoluMin
    val NAVY = Color.parseColor("#0A1A4A")
    val BLUE = Color.parseColor("#1F52C0")
    val CYAN = Color.parseColor("#5CF0FF")
    val PANEL = Color.parseColor("#D9071436")
    val MUTED = Color.parseColor("#A9C4F5")
    val WHITE = Color.WHITE

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun background(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(NAVY, BLUE)
    )

    /** Gambar konten sampai ke bawah status bar dan navigation bar (edge-to-edge). */
    @Suppress("DEPRECATION")
    fun styleBars(a: Activity) {
        if (Build.VERSION.SDK_INT >= 30) {
            a.window.setDecorFitsSystemWindows(false)
        } else {
            a.window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        a.window.statusBarColor = Color.TRANSPARENT
        a.window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            a.window.isNavigationBarContrastEnforced = false
        }
    }

    /** Mengembalikan [kiri, atas, kanan, bawah] area yang tertutup bar sistem/poni layar. */
    @Suppress("DEPRECATION")
    fun insets(ins: WindowInsets): IntArray =
        if (Build.VERSION.SDK_INT >= 30) {
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            intArrayOf(i.left, i.top, i.right, i.bottom)
        } else {
            intArrayOf(
                ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                ins.systemWindowInsetRight, ins.systemWindowInsetBottom
            )
        }

    fun button(ctx: Context, label: String, filled: Boolean): Button {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(ctx, 16).toFloat()
            if (filled) {
                setColor(CYAN)
            } else {
                setColor(Color.TRANSPARENT)
                setStroke(dp(ctx, 2), CYAN)
            }
        }
        val ripple = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), bg, null)
        return Button(ctx).apply {
            text = label
            isAllCaps = true
            textSize = 16f
            setTextColor(if (filled) NAVY else CYAN)
            background = ripple
            stateListAnimator = null
            minimumHeight = dp(ctx, 60)
        }
    }
}
