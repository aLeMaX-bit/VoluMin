package com.example.volumin

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.animation.OvershootInterpolator
import android.widget.Button

object Ui {
    // Warna diambil dari logo VoluMin
    val NAVY = Color.parseColor("#0A1A4A")
    val BLUE = Color.parseColor("#1F52C0")
    val CYAN = Color.parseColor("#5CF0FF")
    val PANEL = Color.parseColor("#D9071436")
    val MUTED = Color.parseColor("#A9C4F5")
    val WHITE = Color.WHITE

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun background(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(NAVY, BLUE)
    )

    /** Gambar konten sampai ke bawah status bar dan navigation bar (edge-to-edge). */
    @Suppress("DEPRECATION")
    fun styleBars(a: Activity) {
        if (Build.VERSION.SDK_INT >= 30) {
            a.window.setDecorFitsSystemWindows(false)
        } else {
            a.window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        a.window.statusBarColor = Color.TRANSPARENT
        a.window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            a.window.isNavigationBarContrastEnforced = false
        }
    }

    /** Mengembalikan [kiri, atas, kanan, bawah] area yang tertutup bar sistem/poni layar. */
    @Suppress("DEPRECATION")
    fun insets(ins: WindowInsets): IntArray =
        if (Build.VERSION.SDK_INT >= 30) {
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            intArrayOf(i.left, i.top, i.right, i.bottom)
        } else {
            intArrayOf(
                ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                ins.systemWindowInsetRight, ins.systemWindowInsetBottom
            )
        }

    /**
     * Animasi sentuhan: saat ditekan, tampilan mengecil sedikit dan meredup;
     * saat dilepas, memantul kembali. Tidak mengganggu klik.
     */
    @SuppressLint("ClickableViewAccessibility")
    fun pressEffect(v: View) {
        v.setOnTouchListener { view, ev ->
            if (view.isEnabled) {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> view.animate()
                        .scaleX(0.94f).scaleY(0.94f).alpha(0.8f)
                        .setDuration(90).setInterpolator(null).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                        .scaleX(1f).scaleY(1f).alpha(1f)
                        .setDuration(260).setInterpolator(OvershootInterpolator(2.5f)).start()
                }
            }
            false
        }
    }

    /** Untuk teks yang bisa diketuk: riak (ripple) berujung membulat + animasi sentuhan. */
    fun touchable(v: View) {
        val mask = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(v.context, 12).toFloat()
        }
        v.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), null, mask)
        pressEffect(v)
    }

    fun button(ctx: Context, label: String, filled: Boolean): Button {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(ctx, 16).toFloat()
            if (filled) {
                setColor(CYAN)
            } else {
                setColor(Color.TRANSPARENT)
                setStroke(dp(ctx, 2), CYAN)
            }
        }
        // Riak gelap di atas tombol cyan, riak terang di atas tombol outline
        val rippleColor = if (filled) 0x660A1A4A else 0x66FFFFFF
        val ripple = RippleDrawable(ColorStateList.valueOf(rippleColor), bg, null)
        return Button(ctx).apply {
            text = label
            isAllCaps = true
            textSize = 16f
            setTextColor(if (filled) NAVY else CYAN)
            background = ripple
            stateListAnimator = null
            minimumHeight = dp(ctx, 60)
            pressEffect(this)
        }
    }
}
