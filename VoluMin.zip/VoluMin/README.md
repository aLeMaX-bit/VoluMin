# VoluMin

Meredam volume HP Android lebih pelan dari level minimum bawaan, memakai `LoudnessEnhancer` (gain negatif) pada audio session global.

- Target Android 16 (API 36), minimal Android 8.0 (API 26)
- Kontrol dari aplikasi, notifikasi (-, +, jeda/lanjutkan, matikan), dan tile Pengaturan Cepat
- 30 bahasa (mengikuti bahasa sistem atau pengaturan bahasa per-aplikasi)
- Data pembuat ada di `app/src/main/java/com/example/volumin/AboutInfo.kt`

## Build lewat GitHub
1. Push repo ini ke GitHub (branch `main`).
2. Buka tab **Actions** > workflow **Build APK** > tunggu selesai.
3. Unduh artifact **VoluMin-debug-apk**, ekstrak, lalu install `app-debug.apk`.
